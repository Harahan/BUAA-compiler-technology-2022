package Syntax.Decl.InitVal;

public interface InitVal {
    boolean isConst();
}
