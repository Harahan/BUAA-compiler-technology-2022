package Middle.Optimization;

public class CollisionGraph {

}
