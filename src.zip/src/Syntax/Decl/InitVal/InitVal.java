package Syntax.Decl.InitVal;

public interface InitVal {
}
