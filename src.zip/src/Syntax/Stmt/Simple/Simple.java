package Syntax.Stmt.Simple;

public interface Simple {
}
