package Middle;

import Middle.Util.Code;

import java.util.ArrayList;

public class MidCodeList {
    private ArrayList<Code> codes = new ArrayList<>();
    public static String add(Code.Op instr, String ord1, String ord2, String res) {
        return "";
    }
}
