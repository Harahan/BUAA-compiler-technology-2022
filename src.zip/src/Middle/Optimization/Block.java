package Middle.Optimization;

public class Block {
}
