package Middle.Optimization;

import Middle.Util.Code;
import Middle.Util.Code.Op;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class DataFlow {

    private HashMap<Integer, Block> num2block;

    private void divideBlock(ArrayList<Code> codes) {

    }
}
