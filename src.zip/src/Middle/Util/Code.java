package Middle.Util;

public class Code {
    public enum Op {
        ASSIGN("="), ADD("+"), SUB("-"), MUL("*"), DIV("/"), MOD("%"), NOT("!"),

        GET_INT("getInt"), PRINT_STR("print_str"), PRINT_INT("print_int"),

        FUNC("func"), FUNC_END("func_end"), PREPARE_CALL("prepare_call"), CALL("call"),
        PUSH_PAR_INT("push_para_int"), PUSH_PAR_ADDR("push_para_addr"), RETURN("return"),

        JUMP("jump"), COND_JUMP("condition_jump"), LABEL("label");

        private String op;

        Op(String op) {
            this.op = op;
        }
    }
    private final Op instr;
    private final String ord1;
    private final String ord2;
    private final String res;

    public Code(Op instr, String ord1, String ord2, String res) {
        this.instr = instr;
        this.ord1 = ord1;
        this.ord2 = ord2;
        this.res = res;
    }
}
