package Backend.Util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Stack;

public class ParamGraph {
    public final ArrayList<HashSet<Integer>> G;
    public final Stack<Integer> stk = new Stack<>();
    public final HashSet<Integer> vis = new HashSet<>();
    public HashMap<Integer, Integer> dfn = new HashMap<>();
    public HashMap<Integer, Integer> low = new HashMap<>();

    public HashSet<HashSet<Integer>> cycV = new HashSet<>();

    public HashSet<HashMap<Integer, Integer>> cycE = new HashSet<>();

    public HashMap<Integer, Integer> cutE = new HashMap<>();

    public int t = 0;

    public ParamGraph(ArrayList<HashSet<Integer>> G) {
        this.G = G; // no self loop
    }

    public void tarjan(int u) {
        vis.add(u);
        stk.push(u);
        dfn.put(u, low.put(u, ++t));
        for (int v : G.get(u)) {
            if (!dfn.containsKey(v)) {
                tarjan(v);
                low.put(u, Math.min(low.get(u), low.get(v)));
            } else if (vis.contains(v)) {
                low.put(u, Math.min(low.get(u), dfn.get(v)));
            }
        }
        if (dfn.get(u).equals(low.get(u))) {
            int v;
            HashSet<Integer> V = new HashSet<>();
            do {
                v = stk.pop();
                V.add(v);
                vis.remove(v);
            } while (v != u);
            if (V.size() > 1) cycV.add(V);
        }
    }

    public void solve() {
        for (int i = 0; i < G.size(); ++i) {
            if (!dfn.containsKey(i)) tarjan(i);
        }
        // set cycE
        for (HashSet<Integer> V : cycV) {
            HashMap<Integer, Integer> E = new HashMap<>();
            for (int u : V) {
                for (int v : G.get(u)) {
                    if (V.contains(v)) E.put(u, v);
                }
            }
            cycE.add(E);
        }
        // 基环外向树森林，断掉环上一条边，然后对整张图做拓扑排序
        // set cutE
        for (HashMap<Integer, Integer> E : cycE) {
            for (int u : E.keySet()) {
                int v = E.get(u);
                G.get(u).remove(v);
                cutE.put(u, v);
            }
        }
        // 对每一棵基环外向树做拓扑排序

    }
}
